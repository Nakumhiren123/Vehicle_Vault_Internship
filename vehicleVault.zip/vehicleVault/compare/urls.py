from django.urls import path
from django.http import HttpResponse
from . import views
urlpatterns = [
     path("test/", lambda request: HttpResponse("Compare Working")),
    path("admin/", views.adminDashboardView, name="admin-dashboard"),
    path("user/", views.userDashboardView, name="user-dashboard"),
    path('cars/', views.car_list, name='car_list'),
    path('cars/add/', views.car_create, name='car_create'),
    path('cars/edit/<int:pk>/', views.car_update, name='car_update'),
    path('cars/delete/<int:pk>/', views.car_delete, name='car_delete'),
    path('cars/public/', views.public_car_list, name='public_car_list'),
    path('cars/<int:pk>/', views.car_detail, name='car_detail'),
    path('review/delete/<int:pk>/', views.delete_review, name='delete_review'),
    path('cars/compare/', views.compare_cars, name='compare_cars'),
    # path('admin/cars/', views.car_list, name='car_list'),
    # path('admin/cars/add/', views.car_create, name='car_create'),
    # path('admin/cars/edit/<int:pk>/', views.car_update, name='car_update'),
    # path('admin/cars/delete/<int:pk>/', views.car_delete, name='car_delete'),
]
