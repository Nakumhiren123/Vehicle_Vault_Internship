from django.shortcuts import render, redirect, get_object_or_404
# Create your views here.
from django.contrib.auth.decorators import login_required
from .decorators import role_required
from .models import Car, Review
from .forms import CarForm, ReviewForm
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Avg

# @login_required(login_url='login')
@role_required(allowed_roles=['admin'])
def adminDashboardView(request):
    return render(request, 'compare/admin/admin_dashboard.html')

# @login_required(login_url='login')
@role_required(allowed_roles=['user'])
def userDashboardView(request):
    return render(request, 'compare/user/user_dashboard.html')



from django.core.paginator import Paginator

@role_required(allowed_roles=['admin'])
def car_list(request):

    search_query = request.GET.get('search')

    cars = Car.objects.all().order_by('id')

    if search_query:
        cars = cars.filter(carName__icontains=search_query)

    paginator = Paginator(cars, 5)
    page_number = request.GET.get('page')
    cars = paginator.get_page(page_number)

    brand_filter = request.GET.get('brand')

    if brand_filter:
        cars = cars.filter(brand__icontains=brand_filter)

    return render(request, 'compare/admin/car_list.html', {
        'cars': cars,
        'search_query': search_query
    })

def public_car_list(request):
    cars = Car.objects.filter(status=True).order_by('id')
    return render(request, 'compare/user/car_list.html', {'cars':cars})


@role_required(allowed_roles=['admin'])
def car_create(request):
    form = CarForm(request.POST or None, request.FILES or None)
    if form.is_valid():
        form.save()
        return redirect('car_list')
    return render(request, 'compare/admin/car_form.html', {'form': form})


@role_required(allowed_roles=['admin'])
def car_update(request, pk):
    car = get_object_or_404(Car, pk=pk)
    form = CarForm(request.POST or None, request.FILES or None, instance=car)

    if request.method == "POST":
        print("FILES:", request.FILES)   # DEBUG LINE

    if form.is_valid():
        form.save()
        print("SAVED SUCCESSFULLY")     # DEBUG LINE
        return redirect('car_list')

    return render(request, 'compare/admin/car_form.html', {'form': form})


@role_required(allowed_roles=['admin'])
def car_delete(request, pk):
    car = get_object_or_404(Car, pk=pk)
    car.delete()
    return redirect('car_list')



from django.db.models import Avg

def car_detail(request, pk):
    car = get_object_or_404(Car, pk=pk)
    reviews = Review.objects.filter(car=car).order_by('-createdAt')

    average_rating = reviews.aggregate(avg=Avg('rating'))['avg']
    average_rating = round(average_rating, 1) if average_rating else 0

    form = ReviewForm()

    if request.method == "POST":
        if request.user.is_authenticated:

            # Restrict 1 review per user
            if Review.objects.filter(car=car, user=request.user).exists():
                return redirect('car_detail', pk=car.id)

            form = ReviewForm(request.POST)
            if form.is_valid():
                review = form.save(commit=False)
                review.car = car
                review.user = request.user
                review.save()
                return redirect('car_detail', pk=car.id)

    return render(request, 'compare/user/car_detail.html', {
        'car': car,
        'reviews': reviews,
        'form': form,
        'average_rating': average_rating
    })

@staff_member_required
def delete_review(request, pk):
    review = get_object_or_404(Review, pk=pk)
    car_id = review.car.id
    review.delete()
    return redirect('car_detail', pk=car_id)

def compare_cars(request):
    car_ids = request.GET.getlist('cars')
    print("Selected IDs:", car_ids)  # DEBUG

    cars = Car.objects.filter(id__in=car_ids)

    comparison_data = []

    for car in cars:
        avg_rating = Review.objects.filter(car=car).aggregate(
            Avg('rating')
        )['rating__avg'] or 0

        comparison_data.append({
            'car': car,
            'avg_rating': round(avg_rating, 1)
        })

    return render(request, 'compare/user/compare.html', {
        'comparison_data': comparison_data
    })